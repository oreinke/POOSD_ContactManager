# POOSD_ContactManager

A simple web application to manage contacts using LAMP stack.

## Features
- Front page
- User logins
- Account creation/deletion
